# datadivecsv

`datadivecsv` es una herramienta de Python para realizar Análisis Exploratorio de Datos (EDA) en archivos CSV.

## Instalación

Puedes instalar este paquete usando pip:

```bash
pip install datadivecsv
```

## Uso

<!-- Aquí puedes poner ejemplos de cómo usar tu paquete. -->

## Contribuir

Las contribuciones son bienvenidas. Por favor, revisa las `issues` en GitHub para ver cómo puedes contribuir.

## Licencia

Este proyecto está bajo la Licencia MIT.
